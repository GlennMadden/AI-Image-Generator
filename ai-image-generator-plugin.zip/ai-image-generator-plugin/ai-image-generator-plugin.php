<?php
/*
Plugin Name: AI Image Generator with Enhanced Timer
Description: AI Image Generator Plugin with a sleek countdown timer and improved UI for image generation.
Version: 1.5
Author: Your Name
GitHub Plugin URI: https://github.com/yourusername/your-repository
GitHub Branch: main
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Step 1: Register the API key setting
function ai_image_generator_add_settings_page() {
    add_options_page(
        'AI Image Generator Settings', 
        'AI Image Generator', 
        'manage_options', 
        'ai-image-generator', 
        'ai_image_generator_settings_page'
    );
}
add_action('admin_menu', 'ai_image_generator_add_settings_page');

function ai_image_generator_settings_page() {
    ?>
    <div class="wrap">
        <h1>AI Image Generator Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ai_image_generator_settings_group');
            do_settings_sections('ai-image-generator');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">OpenAI API Key</th>
                    <td><input type="text" name="ai_image_generator_api_key" value="<?php echo esc_attr(get_option('ai_image_generator_api_key')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

function ai_image_generator_register_settings() {
    register_setting('ai_image_generator_settings_group', 'ai_image_generator_api_key');
}
add_action('admin_init', 'ai_image_generator_register_settings');

// Step 2: Shortcode Logic with Professional Design
function ai_image_generator_inject_shortcode() {
    function ai_image_generation_shortcode() {
        ob_start();
        ?>
        <form id="ai-image-form" style="text-align: center; margin: 20px 0;">
            <label for="description" style="font-weight: bold; font-size: 16px; margin-bottom: 10px; display: block;">Enter a description to generate an image:</label>
            <input type="text" id="description" placeholder="Describe your image" style="width: 100%; max-width: 400px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; margin-bottom: 10px;" />
            <button type="submit" style="padding: 10px 20px; font-size: 16px; background-color: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer;">Generate Image</button>
        </form>

        <div id="image-container" style="text-align: center;">
            <!-- Circular Timer -->
            <div id="loading-spinner" style="display:none; margin-top: 20px;">
                <div class="circle-wrap">
                    <div class="circle">
                        <div class="mask full">
                            <div class="fill"></div>
                        </div>
                        <div class="mask half">
                            <div class="fill"></div>
                        </div>
                        <div class="inside-circle">10</div> <!-- Countdown goes here -->
                    </div>
                </div>
                <p style="font-size: 18px; margin-top: 20px;">Generating your image...</p>
            </div>
            <img id="generated-image" src="" alt="Generated AI Image" style="display:none; max-width: 100%; height: auto; margin-top: 20px; border: 1px solid #ddd; border-radius: 5px; box-shadow: 0 2px 8px rgba(0,0,0,0.2);" />
        </div>

        <style>
            .circle-wrap {
                width: 150px;
                height: 150px;
                background: #e6e2e7;
                border-radius: 50%;
                position: relative;
                margin: 20px auto;
            }
            .circle .mask, .circle .fill {
                width: 150px;
                height: 150px;
                position: absolute;
                border-radius: 50%;
            }
            .circle .mask {
                clip: rect(0px, 150px, 150px, 75px);
            }
            .circle .mask .fill {
                clip: rect(0px, 75px, 150px, 0px);
                background-color: #3498db;
            }
            .circle .inside-circle {
                width: 120px;
                height: 120px;
                border-radius: 50%;
                background: #fff;
                line-height: 120px;
                text-align: center;
                margin-top: 15px;
                margin-left: 15px;
                position: absolute;
                z-index: 100;
                font-size: 2em;
                font-weight: bold;
            }
            .mask.full, .fill {
                animation: fill 10s linear infinite;
            }
            @keyframes fill {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>

        <script>
            document.getElementById('ai-image-form').addEventListener('submit', async function(event) {
                event.preventDefault();

                const description = document.getElementById('description').value;
                const apiKey = '<?php echo esc_js(get_option('ai_image_generator_api_key')); ?>';

                // Clear previous image and reset spinner
                const image = document.getElementById('generated-image');
                image.style.display = 'none';
                image.src = '';

                // Show loading spinner with circular countdown
                const loadingSpinner = document.getElementById('loading-spinner');
                const insideCircle = document.querySelector('.inside-circle');
                loadingSpinner.style.display = 'block';

                let timer = 10;
                insideCircle.textContent = timer;

                // Countdown timer logic
                const interval = setInterval(() => {
                    timer--;
                    insideCircle.textContent = timer;
                    if (timer <= 0) {
                        clearInterval(interval);
                    }
                }, 1000);

                // Fetch the generated image
                const response = await fetch('https://api.openai.com/v1/images/generations', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        prompt: description,
                        n: 1,
                        size: '1024x1024'
                    })
                });

                const data = await response.json();
                const imageUrl = data.data[0].url;

                // Hide spinner and show the generated image
                loadingSpinner.style.display = 'none';
                image.src = imageUrl;
                image.style.display = 'block';
            });
        </script>
        <?php
        return ob_get_clean();
    }

    add_shortcode('ai_image_generator', 'ai_image_generation_shortcode');
}
add_action('init', 'ai_image_generator_inject_shortcode');

?>
